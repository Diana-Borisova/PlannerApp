package com.example.musicdb.model.entity;

public enum ArtistEnum {
    Queen, Metallica, Madonna
}
