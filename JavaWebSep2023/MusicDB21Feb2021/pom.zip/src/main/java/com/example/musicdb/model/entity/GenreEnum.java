package com.example.musicdb.model.entity;

public enum GenreEnum {
    Pop, Rock, Metal, Other
}
