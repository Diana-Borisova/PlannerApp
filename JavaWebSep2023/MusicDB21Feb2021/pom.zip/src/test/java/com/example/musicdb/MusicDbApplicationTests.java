package com.example.musicdb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MusicDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
