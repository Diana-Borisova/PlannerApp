package com.likebookapp.model.entity;

public enum MoodEnum {
    HAPPY, SAD, INSPIRED

}
