package com.example.likebook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LikebookApplicationTests {

	@Test
	void contextLoads() {
	}

}
