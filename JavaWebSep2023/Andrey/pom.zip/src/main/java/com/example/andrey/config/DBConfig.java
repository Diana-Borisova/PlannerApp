package com.example.andrey.config;

import com.example.andrey.model.entity.CategoryEnum;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Locale;

@Configuration
public class DBConfig {

}
