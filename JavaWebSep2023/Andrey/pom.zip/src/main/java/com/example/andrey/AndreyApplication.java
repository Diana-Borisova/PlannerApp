package com.example.andrey;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AndreyApplication {

	public static void main(String[] args) {
		SpringApplication.run(AndreyApplication.class, args);
	}

}
