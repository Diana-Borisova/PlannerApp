package com.example.andrey.model.entity;

import org.springframework.stereotype.Component;


public enum CategoryEnum {
    SHIRT, DENIM, SHORTS, JACKET


}
