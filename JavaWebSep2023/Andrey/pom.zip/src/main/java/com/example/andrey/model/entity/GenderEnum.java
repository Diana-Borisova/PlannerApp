package com.example.andrey.model.entity;

public enum GenderEnum {
    Male, Female
}
