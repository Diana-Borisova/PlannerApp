package com.example.andrey;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AndreyApplicationTests {

	@Test
	void contextLoads() {
	}

}
