package com.battleships;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BattleShipsApplicationTests {

    @Test
    void contextLoads() {
    }

}
