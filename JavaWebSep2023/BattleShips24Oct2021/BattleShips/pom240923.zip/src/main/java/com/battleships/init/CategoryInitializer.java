package com.battleships.init;


import com.battleships.repository.CategoryRepository;
import com.battleships.model.entity.Category;
import com.battleships.model.entity.ShipType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Arrays;

@Component
public class CategoryInitializer implements CommandLineRunner {

    private final CategoryRepository categoryRepository;

    @Autowired
    public CategoryInitializer(CategoryRepository categoryRepository) {
      this.categoryRepository = categoryRepository;
    }


    @Override
    public void run(String... args) throws Exception {
        if (this.categoryRepository.count() != 0) {
            return;
        }

        Arrays.stream(ShipType.values())
                .forEach(name -> {
                    Category category = new Category(name);

                    this.categoryRepository.save(category);
                });
    }
}
