package com.battleships.model.entity;

public enum ShipType  {
    BATTLE, CARGO, PATROL;
}
