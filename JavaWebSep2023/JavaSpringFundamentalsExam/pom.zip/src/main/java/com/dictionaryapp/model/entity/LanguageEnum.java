package com.dictionaryapp.model.entity;

public enum LanguageEnum {
    GERMAN, SPANISH, FRENCH, ITALIAN
}
