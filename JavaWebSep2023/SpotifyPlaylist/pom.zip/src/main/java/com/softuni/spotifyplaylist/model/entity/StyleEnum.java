package com.softuni.spotifyplaylist.model.entity;

public enum StyleEnum {
    POP, ROCK, JAZZ
}
