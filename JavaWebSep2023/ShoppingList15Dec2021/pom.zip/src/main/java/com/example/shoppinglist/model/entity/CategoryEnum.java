package com.example.shoppinglist.model.entity;

public enum CategoryEnum {
    Food, Drink, Household, Other

}
